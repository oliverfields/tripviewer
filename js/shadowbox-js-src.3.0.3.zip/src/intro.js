/*!
 * Shadowbox.js, version 3.0.3
 * http://shadowbox-js.com/
 *
 * Copyright 2007-2010, Michael J. I. Jackson
 * 2010-03-10 00:00:00 +0000
 */
(function(window, undefined) {
